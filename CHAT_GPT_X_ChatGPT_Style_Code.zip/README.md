# CHAT GPT X — Android AI Assistant

Features included:
- AI chat via OpenAI-compatible Chat Completions API
- Web search via an optional search API (Tavily-compatible endpoint)
- AI image generation via an image API endpoint (provider-specific; configure response parsing)
- PDF and text-file import and extraction (PDFBox Android)
- Firebase Authentication (email/password) and Firestore cloud chat history (requires your Firebase project)
- Speech-to-text and text-to-speech

## Before running
1. Open the project in Android Studio.
2. Configure `app/src/main/java/com/example/aichat/MainActivity.kt`.
3. Add your AI provider API key in `AI_API_KEY`.
4. Add a web-search API key in `SEARCH_API_KEY` if you want web search.
5. For Firebase login/cloud history, create a Firebase project, add an Android app with package `com.example.aichat`, download `google-services.json` into the `app/` directory, enable Email/Password Authentication and Firestore, then uncomment the Google Services plugin/dependency lines in the Gradle files as marked.
6. Configure image generation endpoint/model to match your provider. Image generation APIs differ; the included client expects a response containing `data[0].url` (OpenAI Images API-style).

## Security
For a public app, do not embed API keys in the APK. A determined user can extract them. Use a backend proxy and store keys on the server. This starter uses placeholders so you can add your own keys as requested.

## Notes
- Search uses a Tavily-compatible API request format; adapt endpoint/JSON parsing if your provider differs.
- PDF parsing extracts selectable text; scanned PDFs need OCR, which is not included.
- Firebase is scaffolded but requires your Firebase project configuration before login/cloud sync works.
- No proprietary ChatGPT code or models are included.
