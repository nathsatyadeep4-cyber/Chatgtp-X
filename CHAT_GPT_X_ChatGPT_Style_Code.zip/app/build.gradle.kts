plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    // Firebase: uncomment after adding google-services.json and enabling plugin above.
    // id("com.google.gms.google-services")
}

android {
    namespace = "com.example.aichat"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.aichat"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.json:json:20240303")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    // Firebase: uncomment these after configuring your Firebase project.
    // implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    // implementation("com.google.firebase:firebase-auth-ktx")
    // implementation("com.google.firebase:firebase-firestore-ktx")
}
