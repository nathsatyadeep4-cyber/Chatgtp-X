package com.example.aichat

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * CHAT GPT X — ChatGPT-inspired Android chat UI.
 * This is original starter code, not OpenAI's private source code.
 */
class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    companion object {
        // Add your own provider API key and compatible endpoint/model.
        private const val AI_API_KEY = "ADD_YOUR_AI_API_KEY_HERE"
        private const val AI_API_URL = "https://api.openai.com/v1/chat/completions"
        private const val AI_MODEL = "gpt-4o-mini"

        // Optional Tavily-compatible web search.
        private const val SEARCH_API_KEY = "ADD_YOUR_SEARCH_API_KEY_HERE"
        private const val SEARCH_API_URL = "https://api.tavily.com/search"

        // Optional OpenAI Images API-style endpoint.
        private const val IMAGE_API_KEY = "ADD_YOUR_IMAGE_API_KEY_HERE"
        private const val IMAGE_API_URL = "https://api.openai.com/v1/images/generations"
        private const val IMAGE_MODEL = "gpt-image-1"
    }

    private val http = OkHttpClient()
    private val history = JSONArray()
    private lateinit var chatColumn: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendButton: ImageButton
    private lateinit var status: TextView
    private var lastReply = ""
    private var attachedText = ""
    private var tts: TextToSpeech? = null

    private val speechLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val words = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!words.isNullOrEmpty()) input.setText(words[0])
        }
    }

    private val filePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) lifecycleScope.launch {
            try {
                attachedText = withContext(Dispatchers.IO) { readDocument(uri) }.take(24000)
                addBubble("CHAT GPT X", "File attached. Extracted ${attachedText.length} characters. Send a question to analyze it.", false)
                status.text = "File ready"
            } catch (e: Exception) {
                addBubble("CHAT GPT X", "Could not read file: ${e.message}", false)
            }
        }
    }

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            addBubble("CHAT GPT X", "Image selected. This starter does not yet upload image bytes to a vision model; connect a vision-capable API to enable image understanding.", false)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        tts = TextToSpeech(this, this)
        history.put(JSONObject().put("role", "system").put(
            "content", "You are CHAT GPT X, a helpful AI assistant. Respond clearly in the user's language."
        ))
        buildInterface()
        addBubble("CHAT GPT X", "Hi! I'm CHAT GPT X. How can I help you today?", false)
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        val brand = TextView(this).apply {
            text = "CHAT GPT X"
            textSize = 20f
            setTextColor(Color.rgb(25, 25, 25))
            setTypeface(null, Typeface.BOLD)
        }
        val spacer = Space(this)
        status = TextView(this).apply {
            text = "AI assistant"
            textSize = 12f
            setTextColor(Color.rgb(105, 105, 105))
        }
        header.addView(brand)
        header.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        header.addView(status)

        val divider = View(this).apply { setBackgroundColor(Color.rgb(235, 235, 235)) }

        // Scrollable conversation area
        scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(dp(10), dp(10), dp(10), dp(14))
        }
        chatColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(chatColumn)

        // Quick tools row
        val toolsScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tools.addView(toolButton("＋ File / PDF") { filePicker.launch("*/*") })
        tools.addView(toolButton("▧ Image") { imagePicker.launch("image/*") })
        tools.addView(toolButton("⌕ Web Search") { doWebSearch() })
        tools.addView(toolButton("✦ Create Image") { doImageGeneration() })
        toolsScroll.addView(tools)

        // Composer
        val composerOuter = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(8))
            setBackgroundColor(Color.WHITE)
        }
        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            setPadding(dp(8), dp(4), dp(5), dp(4))
            background = rounded(Color.rgb(247, 247, 248), dp(26))
        }
        input = EditText(this).apply {
            hint = "Message CHAT GPT X"
            textSize = 16f
            setTextColor(Color.rgb(30, 30, 30))
            setHintTextColor(Color.rgb(125, 125, 125))
            background = null
            minLines = 1
            maxLines = 5
            setPadding(dp(10), dp(8), dp(4), dp(8))
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendChat(); true } else false
            }
        }
        val voice = ImageButton(this).apply {
            contentDescription = "Voice input"
            setImageResource(android.R.drawable.ic_btn_speak_now)
            background = rounded(Color.TRANSPARENT, dp(24))
            setOnClickListener { startSpeech() }
        }
        sendButton = ImageButton(this).apply {
            contentDescription = "Send message"
            setImageResource(android.R.drawable.arrow_up_float)
            setColorFilter(Color.WHITE)
            background = rounded(Color.rgb(25, 25, 25), dp(24))
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { sendChat() }
        }
        composer.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        composer.addView(voice, LinearLayout.LayoutParams(dp(42), dp(42)))
        composer.addView(sendButton, LinearLayout.LayoutParams(dp(42), dp(42)))
        val footnote = TextView(this).apply {
            text = "CHAT GPT X can make mistakes. Check important information."
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(125, 125, 125))
            setPadding(0, dp(5), 0, 0)
        }
        composerOuter.addView(composer)
        composerOuter.addView(footnote)

        root.addView(header)
        root.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(toolsScroll)
        root.addView(composerOuter)
        setContentView(root)
    }

    private fun toolButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            setTextColor(Color.rgb(55, 55, 55))
            background = rounded(Color.rgb(247, 247, 248), dp(20))
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { action() }
            val p = LinearLayout.LayoutParams(-2, dp(40))
            p.setMargins(dp(4), 0, dp(4), 0)
            layoutParams = p
        }

    private fun addBubble(who: String, message: String, user: Boolean) {
        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val label = TextView(this).apply {
            text = who
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(if (user) Color.rgb(40, 80, 140) else Color.rgb(30, 130, 90))
        }
        val body = TextView(this).apply {
            text = message
            textSize = 16f
            setTextColor(Color.rgb(35, 35, 35))
            setPadding(0, dp(4), 0, dp(2))
            textIsSelectable = true
        }
        wrapper.addView(label)
        wrapper.addView(body)
        chatColumn.addView(wrapper)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendChat() {
        var prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        if (AI_API_KEY.startsWith("ADD_YOUR")) {
            addBubble("Setup", "Add your AI_API_KEY in MainActivity.kt before sending messages.", false)
            return
        }
        if (attachedText.isNotBlank()) {
            prompt += "\n\nUse this extracted document text to answer:\n${attachedText}"
            attachedText = ""
        }
        input.setText("")
        addBubble("You", prompt, true)
        history.put(JSONObject().put("role", "user").put("content", prompt))
        status.text = "Thinking…"
        sendButton.isEnabled = false
        lifecycleScope.launch {
            try {
                val answer = withContext(Dispatchers.IO) { chatRequest() }
                lastReply = answer
                history.put(JSONObject().put("role", "assistant").put("content", answer))
                addBubble("CHAT GPT X", answer, false)
                status.text = "AI assistant"
            } catch (e: Exception) {
                addBubble("Error", e.message ?: "Request failed. Check API key, internet, model, and endpoint.", false)
                status.text = "Connection issue"
            } finally {
                sendButton.isEnabled = true
            }
        }
    }

    private fun chatRequest(): String {
        val payload = JSONObject().put("model", AI_MODEL).put("messages", history).put("temperature", 0.7)
        val body = payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder().url(AI_API_URL)
            .header("Authorization", "Bearer $AI_API_KEY")
            .post(body).build()
        http.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IllegalStateException("AI HTTP ${response.code}: $raw")
            return JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
        }
    }

    private fun doWebSearch() {
        val query = input.text.toString().trim()
        if (query.isEmpty()) {
            addBubble("Tip", "Type what you want to search in the message box, then tap Web Search.", false)
            return
        }
        if (SEARCH_API_KEY.startsWith("ADD_YOUR")) {
            addBubble("Setup", "Add SEARCH_API_KEY in MainActivity.kt. Search endpoint is configured for Tavily-compatible API.", false)
            return
        }
        input.setText("")
        addBubble("You · Web Search", query, true)
        status.text = "Searching…"
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val payload = JSONObject().put("api_key", SEARCH_API_KEY).put("query", query)
                        .put("search_depth", "basic").put("max_results", 5)
                    val req = Request.Builder().url(SEARCH_API_URL)
                        .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())).build()
                    http.newCall(req).execute().use { res ->
                        val raw = res.body?.string().orEmpty()
                        if (!res.isSuccessful) throw IllegalStateException("Search HTTP ${res.code}: $raw")
                        val results = JSONObject(raw).optJSONArray("results") ?: JSONArray()
                        buildString {
                            for (i in 0 until results.length()) {
                                val item = results.getJSONObject(i)
                                append("${i + 1}. ${item.optString("title")}\n")
                                append("${item.optString("url")}\n")
                                append("${item.optString("content")}\n\n")
                            }
                        }.ifBlank { "No results returned." }
                    }
                }
                addBubble("Web Search Results", result, false)
            } catch (e: Exception) {
                addBubble("Search Error", e.message ?: "Search failed.", false)
            } finally { status.text = "AI assistant" }
        }
    }

    private fun doImageGeneration() {
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) {
            addBubble("Tip", "Describe the picture you want, then tap Create Image.", false)
            return
        }
        if (IMAGE_API_KEY.startsWith("ADD_YOUR")) {
            addBubble("Setup", "Add IMAGE_API_KEY and confirm your provider's image model and endpoint.", false)
            return
        }
        input.setText("")
        addBubble("You · Image Prompt", prompt, true)
        status.text = "Creating image…"
        lifecycleScope.launch {
            try {
                val url = withContext(Dispatchers.IO) {
                    val payload = JSONObject().put("model", IMAGE_MODEL).put("prompt", prompt)
                        .put("n", 1).put("size", "1024x1024")
                    val req = Request.Builder().url(IMAGE_API_URL)
                        .header("Authorization", "Bearer $IMAGE_API_KEY")
                        .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())).build()
                    http.newCall(req).execute().use { res ->
                        val raw = res.body?.string().orEmpty()
                        if (!res.isSuccessful) throw IllegalStateException("Image API HTTP ${res.code}: $raw")
                        val data = JSONObject(raw).getJSONArray("data").getJSONObject(0)
                        data.optString("url").ifBlank { "Image created, but this provider returned no URL. Check its response format." }
                    }
                }
                addBubble("Generated Image", url, false)
            } catch (e: Exception) {
                addBubble("Image Error", e.message ?: "Image generation failed.", false)
            } finally { status.text = "AI assistant" }
        }
    }

    private fun readDocument(uri: Uri): String {
        val mime = contentResolver.getType(uri).orEmpty()
        return if (mime == "application/pdf") {
            contentResolver.openInputStream(uri).use { stream ->
                val pdf = PDDocument.load(stream)
                try { PDFTextStripper().getText(pdf) } finally { pdf.close() }
            }
        } else {
            val name = uri.lastPathSegment.orEmpty().lowercase(Locale.ROOT)
            if (mime.startsWith("text/") || name.endsWith(".txt")) {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
            } else throw IllegalArgumentException("Select a text-based PDF or .txt file.")
        }
    }

    private fun startSpeech() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to CHAT GPT X")
        }
        try { speechLauncher.launch(intent) }
        catch (_: Exception) { Toast.makeText(this, "Speech recognition unavailable on this device.", Toast.LENGTH_LONG).show() }
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
